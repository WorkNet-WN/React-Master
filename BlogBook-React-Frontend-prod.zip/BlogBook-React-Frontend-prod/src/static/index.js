import writerPlaceholder from "./img/writer.png";

import blueBook from "./img/blue_book.svg";
import blueBulb from "./img/blue_bulb.svg";
import blueRead from "./img/blue_read.svg";
import redBook from "./img/red_book.svg";
import redBulb from "./img/red_bulb.svg";
import redRead from "./img/red_read.svg";

import icon from "./img/icon.png";

export {
  icon,
  writerPlaceholder,
  blueBook,
  blueBulb,
  blueRead,
  redBook,
  redBulb,
  redRead,
};
