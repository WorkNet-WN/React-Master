import "./index.css";

import { Component } from "react";

class Base extends Component {
  render() {
    return <div></div>;
  }
}

export default Base;
