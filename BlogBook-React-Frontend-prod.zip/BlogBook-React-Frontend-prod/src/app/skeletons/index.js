import FeedSkeleton from "./Feed";
import ProfileSkeleton from "./Profile";
import UpdateBlogSkeleton from "./UpdateBlog";
import ReadBlogSkeleton from "./ReadBlog";

export { FeedSkeleton, ProfileSkeleton, UpdateBlogSkeleton, ReadBlogSkeleton };
