export const actionTypes = {
  SET_USER_ID: "auth/set/userId",
  SIGNUP_BEGIN: "auth/signup/begin",
  SIGNUP_SUCESS: "auth/signup/success",
  SIGNUP_ERROR: "auth/signup/error",
  LOGIN_BEGIN: "auth/login/begin",
  LOGIN_SUCESS: "auth/login/success",
  LOGIN_ERROR: "auth/login/error",
  LOGOUT: "auth/logout",
};
