export const initialState = {
  followingPk: -1,
  altBlogPk: false,
  dltBlogPk: false,
};
