export const actionTypes = {
  SET_FOLLOWING_PK: "common/setFollowingPk",
  SET_ALT_BLOG_PK: "common/setAltBlogPk",
  SET_DLT_BLOG_PK: "common/setDltBlogPk",
};
