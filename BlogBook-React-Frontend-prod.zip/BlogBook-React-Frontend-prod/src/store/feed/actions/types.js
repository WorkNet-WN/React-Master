export const actionTypes = {
  SET_BLOGS: "blog/setBlogs",
};
