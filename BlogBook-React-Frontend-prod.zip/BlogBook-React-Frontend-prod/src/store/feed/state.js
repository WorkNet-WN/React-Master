export const initialState = {
  blogs: [],
  loading: true,
};
