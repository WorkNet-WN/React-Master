export const actionTypes = {
  SET_TAB: "settings/setTab",
};
