export const actionTypes = {
  RESET_STORE: "blog/resetStore",
  SET_BLOG: "blog/set/blog",
  SET_LOADING: "blog/set/loading",
  SET_SUBMIT_TYPE: "blog/set/submitType",
  SET_AUTHOR: "blog/set/author",
  SET_TITLE: "blog/set/title",
  SET_CONTENT: "blog/set/content",
};
