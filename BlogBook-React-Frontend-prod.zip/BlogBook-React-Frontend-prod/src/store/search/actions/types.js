export const actionTypes = {
  SET_RESULTS: "search/setResults",
  SET_SEARCH_QUERY: "search/setSearchQuery",
  SET_LOADING: "search/setLoading",
  SET_MSG: "search/setMsg",
};
