export const initialState = {
  results: [],
  searchQuery: "",
  loading: false,
  msg: "Start typing to search ...",
};
